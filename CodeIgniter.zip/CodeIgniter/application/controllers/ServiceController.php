<?php
      class ServiceController extends CI_Controller{
      public function service()
      {
        $this->load->helper(array('url','form'));

        $this->load->view('templates/header');
        $this->load->view('Service');
        $this->load->view('templates/footer');
      }

      public function addService()
      {
        
        $this->load->library('form_validation');

        $this->form_validation->set_rules("fname","FirstName",'required|alpha',array('required' => 'Please provide a %s it is required ! ','alpha' => '%s must contain only letters!'));
        $this->form_validation->set_rules("lname","LastName",'required|alpha',array('required' => 'Please provide a %s it is required!','alpha'=> '%s must contain only letters !'));
        $this->form_validation->set_rules("email","E-mail",'required|valid_email',array('required' => 'Please provide a %s it is required!'));
        $this->form_validation->set_rules('phone', 'Phone', 'regex_match[/^[0-9]{10}$/]',array('regex_match' => 'You must provide a valid 10 digit %s !'));
        $this->form_validation->set_rules("bname","BusinessName",'alpha', array('alpha'=> '%s must contain only letters!'));


        if ($this->form_validation->run()) 
          {
            
            $this->load->model("serviceModel");
            $data1=array( 
              "email" =>$this->input->post("email"),
              "password" => "123",
              "roleid" => 1
             );
            $this->serviceModel->insert_user($data1);
            $email=$this->input->post("email");
            $sql = $this->db->query("SELECT userid FROM user WHERE email='$email'");
            $query = $sql->result();
      
            $userid = 50;
            foreach($query as $row){
                
                    
                    $userid = $row->userid;
                    break;
              
            }
            $data2=array( 
              "userid" =>$userid,
              "fname" =>$this->input->post("fname"),
              "lname" =>$this->input->post("lname"),
              "phone" =>$this->input->post("phone"),
              "email" =>$this->input->post("email"),
			  "bname" =>$this->input->post("bname")
             );
            $this->serviceModel->insert($data2);

             $from_email = "harshinevraman@gmail.com"; 
             $to_email = $this->input->post('email'); 
       
             //Load email library 
             $this->load->library('email'); 
       
             $this->email->from($from_email, 'Petstore123'); 
             $this->email->to($to_email);
             $this->email->subject('Welcome!'); 
             $this->email->message('Password is 123!'); 
       
             
             $this->email->send();  

            redirect("/serviceController/success");
          }
          else{
            $this->load->helper(array('url','form'));
        $this->load->view('templates/header');
        $this->load->view('Service');
        $this->load->view('templates/footer');
          }

      }

      public function success(){
           $this->load->helper(array('url','form'));
        $this->load->view('templates/header');
        $this->load->view('Service');
        $this->load->view('templates/footer');
       }
    }
?>