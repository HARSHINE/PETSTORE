<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
      class Contact extends CI_Controller{
      public function contacts()
      {
        $this->load->helper(array('url','form'));

        $this->load->view('templates/header');
        $this->load->view('Contactus');
        $this->load->view('templates/footer');
      }

      public function addContact()
      {
        
        $this->load->library('form_validation');

        $this->form_validation->set_rules("fname","FirstName",'required|alpha',array('required' => 'Please provide a %s it is required !','alpha'=> '%s must contain only letters!'));
        $this->form_validation->set_rules("lname","LastName",'required|alpha',array('required' => 'Please provide a %s it is required !','alpha'=> '%s must contain only letters !'));
        $this->form_validation->set_rules("email","E-mail",'required|valid_email',array('required' => 'Please provide a %s it is required!'));
        $this->form_validation->set_rules('phone', 'Phone', 'regex_match[/^[0-9]{10}$/]',array('regex_match' => 'Please provide a valid 10 digit %s !'));
        $this->form_validation->set_rules("comments","Comments",'required',array('required' => 'You must provide a %s !'));

        if ($this->form_validation->run()) 
          {
            
            $this->load->model("contactModel");
            $data=array( 
              "fname" =>$this->input->post("fname"),
              "lname" =>$this->input->post("lname"),
              "email" =>$this->input->post("email"),
              "phone" =>$this->input->post("phone"),
              "comments" =>$this->input->post("comments")
             );
            $this->contactModel->insert($data);
            redirect("/Contact/success");
		   
          }
          else{
            $this->load->helper(array('url','form'));
        $this->load->view('templates/header');
        $this->load->view('Contactus');
        $this->load->view('templates/footer');
          }

      }

      public function success(){
           $this->load->helper(array('url','form'));
        $this->load->view('templates/header');
        $this->load->view('Contactus');
        $this->load->view('templates/footer');
       }
    }
?>