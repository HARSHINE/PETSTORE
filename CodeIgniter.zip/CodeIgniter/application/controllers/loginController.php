<?php
      class loginController extends CI_Controller{
      public function Login()
      {
        $this->load->helper(array('url','form'));

        $this->load->view('templates/headerLogin');
        $this->load->view('Login');
        $this->load->view('templates/footer');
      }

      public function addLogin()
      {
        
        $this->load->library('form_validation');

       
        
        $this->form_validation->set_rules("email","E-mail",'required|valid_email',array('required' => 'Please provide a %s it is required!'));
		$this->form_validation->set_rules("password","Password",'required',array('required' => 'Please provide a %s it is required!'));
       


        if ($this->form_validation->run()) 
          {
             $email=$this->input->post("email");
			  $password=$this->input->post("password");
			  $sql=$this->db->query("SELECT roleid,password FROM user WHERE email='$email'");
			  $query=$sql->result();
			  
			  $roleid=0;
			  $password="";
			  foreach($query as $row){
				  $roleid=$row->roleid;
				  $password=$row->password;
				  break;
			  }
			  if ($roleid == 2&& $password == $password){
				 redirect("/loginController/success1"); 
			  }
			     else if ($roleid == 1&& $password == $password){
				 redirect("/loginController/success2"); 
				 }
				 else
					 redirect("/loginController/Login"); 
              

            
          }
          else{
            $this->load->helper(array('url','form'));
        $this->load->view('templates/headerLogin');
        $this->load->view('Login');
        $this->load->view('templates/footer');
          }

      }

      public function success1(){
           $this->load->helper(array('url','form'));
        $this->load->view('templates/headerLogin');
        $this->load->view('LoginClient');
        $this->load->view('templates/footer');
       }
	   public function success2(){
           $this->load->helper(array('url','form'));
        $this->load->view('templates/headerLogin');
        $this->load->view('LoginBusiness');
        $this->load->view('templates/footer');
       }
	  
    }
?>