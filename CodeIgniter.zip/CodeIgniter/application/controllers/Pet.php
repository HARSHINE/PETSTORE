<?php
Class Pet extends CI_Controller { 
Public function index(){
$this->load->helper('url');
$this->load->view('templates/header');
$this->load->view('index');
$this->load->view('templates/footer');
}


Public function Aboutus(){
$this->load->helper('url');
$this->load->view('templates/header');
$this->load->view('Aboutus');
$this->load->view('templates/footer');
}




 }
 
 ?>