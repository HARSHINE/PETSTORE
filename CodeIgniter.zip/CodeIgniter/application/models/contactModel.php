<?php
class contactModel extends CI_Model{
	public function __construct()
  {
    $this->load->database();
  }
function insert($data){
	
	$this->db->insert("contact",$data);
}
}
?>