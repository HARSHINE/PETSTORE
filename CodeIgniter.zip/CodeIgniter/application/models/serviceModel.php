<?php
class serviceModel extends CI_Model{
	public function __construct()
  {
    $this->load->database();
  }
   function insert_user($data){
	
	$this->db->insert("user",$data);
}
function insert($data){
	
	$this->db->insert("service",$data);
}
}
?>