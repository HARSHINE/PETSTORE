<!DOCTYPE html>

<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title> PetStore</title> 
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/pet.css">
</head>
<body  id="wrapper">
<header> 
<h1>  Pet Store  </h1> 
</header>
<div class="row">
<div class="column left" > 

<nav class="tab">

 <a href="<?php echo base_url();?>index.php/loginController/Login" class="tablinks"> Logout  </a>
</nav>
</div>



