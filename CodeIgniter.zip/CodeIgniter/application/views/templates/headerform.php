<!DOCTYPE html>

<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title> Contactus.html </title> 
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/pet.css">
</head>
<body>
<div id="wrapper">
<header> 
<h1>  Pet Store  </h1> 
</header>
<div class="row">
<div class="column left" > 
<nav class="tab">
<a href="<?php echo base_url();?>index.php/Pet/index" class="tablinks">   Home  </a> 
<a href="<?php echo base_url();?>Aboutus.php/Pet/index" class="tablinks"> About Us  </a> 
<a href="<?php echo base_url();?>index.php/contact/addContact" class="tablinks"> Contact Us  </a> 
 <a href="<?php echo base_url();?>Client.php/Pet/index" class="tablinks"> Client  </a> 
 <a href="<?php echo base_url();?>Service.php/Pet/index" class="tablinks"> Service  </a> 
 <a href="<?php echo base_url();?>Login.php/Pet/index" class="tablinks"> Login  </a>
</nav>
</div>