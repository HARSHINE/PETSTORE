<footer>
 Copyright &copy 2018 Pet Store <br>
 <u><a href="mailto:harshine@venkataraman.com">harshine@venkataraman.com</a> </u>
 </footer>
 </div>
 </div>
	</div>		
</body>
</html>