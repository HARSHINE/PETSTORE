<div class="column right" >
<img src="<?php echo base_url();?>images/pet_store_banner_5.png" >
<article id ="Article">
<hr>  </hr>
<h2>  Client </h2> 
<p>

Required information is marked with an asterisk(*).

<form method="POST" action="<?php echo base_url();?>index.php/clientController/addClient">

	<table>
		<tr>
			<td>* First Name:</td>
			<td><?php echo form_input(array('id'=>'fname','name'=>'fname'));?></td>
			

		</tr>
		<span class="error"><?php echo form_error('fname');?></span>
		
		<tr>
			<td>* Last Name:</td>
			<td><?php echo form_input(array('id'=>'lname','name'=>'lname'));?></td>
			
			
		</tr>
		<span class="error"><?php echo form_error('lname');?></span>    
		<tr>
			<td>* E-mail:</td>
			<td><?php echo form_input(array('id'=>'email','name'=>'email'));?></td>
			
		</tr>
		<span class="error"><?php echo form_error('email');?></span>
		<tr>
			<td>Phone:</td>
			<td><?php echo form_input(array('id'=>'phone','name'=>'phone'));?></td>
			
		</tr>
		<span class="error"><?php echo form_error('phone');?></span>
		<tr>
			<td> Business Name:</td>
			<td><?php echo form_input(array('id'=>'bname','name'=>'bname'));?></td>
			
		</tr>
		<span class="error"><?php echo form_error('bname');?></span>
		<tr>
			<td><?php echo form_submit(array('id'=>'submit','value'=>'Submit')); 
             ?> </td>
		</tr>
		
	</table>
	   <span class="success">
	<?php
	 if($this->uri->segment(2)=="success"){
			echo "The details have been recorded!!Thank you.";
		}?>
	</span>
	</form>
	<!--<?php echo form_close(); ?>--> 
	<article>
  
  </article >