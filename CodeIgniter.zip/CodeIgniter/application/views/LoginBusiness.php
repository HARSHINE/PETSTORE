<div class="column right" >
<img src="<?php echo base_url();?>images/pet_store_banner_5.png" >
<article id ="Article">
<h2> My Business </h2>
<p>

Required information is marked with an asterisk(*).
<form  method="POST" onsubmit="return validate()"action="BuisnessPetStore_action.php">
    
      
  <table cellpadding="0" cellspacing="0" border="0">
  <tr>
  
	
       <td> <label> Business Name</label> <td>
      <td class="spa"><input type="text"  ></td>
       <td> <input type="text" id="bname" name="bname" pattern="[a-zA-A]+" > <td>
	   </tr>
		<tr>
		
		<td> <label><span class="required">*</span> Service </label> <td>
      <td class="spa"><input type="text"  ></td>
       <td> <input type="text" id="service" name="service" required  pattern="[a-zA-A]+"> <td>
	   </tr>
      </tr>
   
      <tr>
       <td colspan="2"><input type="submit" value="Add New One"/>
	  </tr>
	  </table>
  </form>
  </p>
  </article>
 <p>