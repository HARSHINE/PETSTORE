<div class="column right" >
<img src="<?php echo base_url();?>images/pet_store_banner_6.png" >

<article id ="Article">
<h2>  About Us </h2>

<p> We specialize in offering site services to PetStore. We offer a one stop service for clients and businesses. Pet Store offer a special experience on dealing with your pet's needs on the Island.Relax in serenity with our experts taking care of all your pet's needs.</p>

<address>
 
    <p>  Pet Store
 <br> 1999 All Pets Road
 <br> Round Rock, TX 95555
 </p>
 </address>
<p>
 <a href="tel:888-555-5555" class="telephone">888-555-5555</a>
</p>
</article >
 <p>