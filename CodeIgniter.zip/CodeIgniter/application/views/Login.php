<div class="column right" >
<img src="<?php echo base_url();?>images/pet_store_banner_5.png" >
<article id ="Article">
<h2> Login </h2>
<p>

Required information is marked with an asterisk(*).

<form method="POST" action="<?php echo base_url();?>index.php/loginController/addLogin">
    
      
  <table cellpadding="0" cellspacing="0" border="0">
  <tr>
			<td>* E-mail:</td>
			<td><?php echo form_input(array('id'=>'email','name'=>'email'));?></td>
			
		</tr>
		<span class="error"><?php echo form_error('email');?></span>
		<tr>
			<td>* Password:</td>
			<td><?php echo form_input(array('id'=>'password','name'=>'password'));?></td>
			
		</tr>
		<span class="error"><?php echo form_error('password');?></span>
   
      <tr>
       <td><?php echo form_submit(array('id'=>'submit','value'=>'Submit')); 
             ?> </td>
	  </tr>
	  </table>
	  <span class="success">
	<?php
	 if($this->uri->segment(2)=="success"){
			echo "Login!!Thank you.";
		}?>
	</span>
  </form>
  </p>
  </article>
 <p>