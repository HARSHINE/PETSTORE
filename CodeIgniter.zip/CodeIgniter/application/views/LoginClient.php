<div class="column right" >
<img src="<?php echo base_url();?>images/pet_store_banner_5.png" >
<article id ="Article">
<h2> My Pet </h2>
<p>

Required information is marked with an asterisk(*).
<form  method="POST" action="ClientPetStore_action.php">
    
      
  <table cellpadding="0" cellspacing="0" border="0">
  <tr>
  
	
       <td> <label> Client Name:</label> <td>
      <td class="spa"><input type="text" ></td>
       <td> <input type="text" id="cname" name="cname" pattern="[a-zA-A]+" > <td>
	   </tr>
		<tr>
		
		<td> <label><span class="required">*</span>My Pet: </label> <td>
      <td class="spa"><input type="text" ></td>
       <td> <input type="text" id="pet" name="pet" required  pattern="[a-zA-A]+"> <td>
	   </tr>
      </tr>
   
      <tr>
       <td colspan="2"><input type="submit" value="Add New One"/>
	  </tr>
	  </table>
  </form>
  </p>
  </article>
 <p>